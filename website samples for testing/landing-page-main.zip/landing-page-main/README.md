# landing-page
Landing page project @ Odin

https://afiyy.github.io/landing-page/
