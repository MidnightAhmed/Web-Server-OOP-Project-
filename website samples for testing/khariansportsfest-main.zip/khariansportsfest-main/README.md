# khariansportsfest

Website for the event kharian sports fest.

## Updating

All templates for pages should be commited to public
